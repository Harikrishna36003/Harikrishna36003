import { TestBed } from '@angular/core/testing';

import { StockPredictService } from './stock-predict.service';

describe('StockPredictService', () => {
  let service: StockPredictService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(StockPredictService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
