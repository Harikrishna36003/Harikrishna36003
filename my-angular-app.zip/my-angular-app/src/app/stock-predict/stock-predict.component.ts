import { Component } from '@angular/core';
import { StockPredictService } from '../stock-predict.service';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import{TranslateModule} from '@ngx-translate/core';
@Component({
  selector: 'app-stock-predict',
  standalone: true,
  imports: [CommonModule, FormsModule,TranslateModule],
  templateUrl: './stock-predict.component.html',
  styleUrls: ['./stock-predict.component.css']
})
export class StockPredictComponent {
  stockSymbol: string = '';
  predictedPrice: string = '';

  constructor(private stockPredictService: StockPredictService) {}

  predictStock() {
    if (!this.stockSymbol.trim()) {
      alert("Please enter a stock symbol!");
      return;
    }

    this.stockPredictService.getPredictedPrice(this.stockSymbol)
      .subscribe((response: any) => {
        this.predictedPrice = `$${response.predictedPrice.toFixed(2)}`;
      }, error => {
        this.predictedPrice = "Error fetching data.";
      });
  }
}
