import { Component } from '@angular/core';
import { MarketTableComponent } from '../market-table/market-table.component';
import{TranslateModule} from '@ngx-translate/core';
import { CommonModule } from '@angular/common';
@Component({
  selector: 'app-market-overview',
  standalone: true,
  imports: [MarketTableComponent, TranslateModule, CommonModule],
  templateUrl: './market-overview.component.html',
  styleUrl: './market-overview.component.css'
})
export class MarketOverviewComponent {

}
