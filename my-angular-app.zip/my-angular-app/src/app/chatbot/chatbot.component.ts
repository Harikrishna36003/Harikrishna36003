import { Component, OnInit } from '@angular/core';
import { ChatbotService } from '../chatbot.service';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { TranslateModule } from '@ngx-translate/core'; // Import TranslateModule for translations
@Component({
  selector: 'app-chatbot',
  standalone: true,
  imports: [CommonModule, FormsModule, TranslateModule], // Import CommonModule for ngIf, ngFor, etc. and FormsModule for two-way data binding
  templateUrl: './chatbot.component.html',
  styleUrls: ['./chatbot.component.css']
})
export class ChatbotComponent implements OnInit {
  isExpanded = false;
  userQuery = '';
  messages: { text: string; isUser: boolean }[] = [];
  isLoading = false; // Controls loading animation

  constructor(private chatbotService: ChatbotService) {}

  ngOnInit() {
    this.loadMessages();
    this.monitorTokenChanges();
  
    const storedMessages = sessionStorage.getItem('chatHistory');
    this.messages = storedMessages ? JSON.parse(storedMessages) : [];
  
    // Check if JWT token exists
    const token = localStorage.getItem('token'); // Ensure correct reference
    if (!token || token === 'null') { // Extra condition to verify missing token
      console.log("No token found, clearing session storage...");
      sessionStorage.clear(); // Clear session storage
      this.messages = []; // Clear messages array to reflect the change
    }
  }

  loadMessages() {
    const storedMessages = sessionStorage.getItem('chatHistory');
    this.messages = storedMessages ? JSON.parse(storedMessages) : [];
    
    // Check if JWT token exists
    const token = localStorage.getItem('token');
    if (!token) {
      sessionStorage.clear(); // Clear session if token is missing
    }
  }

  monitorTokenChanges() {
    window.addEventListener('storage', (event) => {
      if (event.key === 'token' && !event.newValue) {
        console.log("Token removed! Clearing session storage...");
        sessionStorage.clear(); // Clears chat history when token is removed
      }
    });
  }
  

  toggleChatbot() {
    this.isExpanded = !this.isExpanded;
    if (this.isExpanded) {
      this.loadMessages();
    }
  }

  sendQuery() {
    if (!this.userQuery.trim()) return;

    this.messages.push({ text: this.userQuery, isUser: true });

    this.isLoading = true; // Show loading animation

    this.chatbotService.getChatResponse(this.userQuery).subscribe(response => {
      this.messages.push({ text: response.answer, isUser: false });

      this.isLoading = false; // Hide loading animation

      sessionStorage.setItem('chatHistory', JSON.stringify(this.messages));

      this.userQuery = '';  // Clear input after sending
    });
  }
}
