import { TestBed } from '@angular/core/testing';

import { StockViewerService } from './stock-viewer.service';

describe('StockViewerService', () => {
  let service: StockViewerService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(StockViewerService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
