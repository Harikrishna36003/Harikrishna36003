import { Component } from '@angular/core';
import{TranslateModule} from '@ngx-translate/core';
@Component({
  selector: 'app-vision-section',
  standalone: true,
  imports: [TranslateModule],
  templateUrl: './vision-section.component.html',
  styleUrl: './vision-section.component.css'
})
export class VisionSectionComponent {

}
