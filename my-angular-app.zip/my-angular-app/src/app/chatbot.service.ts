import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ChatbotService {
  private apiUrl = 'http://localhost:5045/api/chat';

  constructor(private http: HttpClient) {}

  getChatResponse(query: string): Observable<{ answer: string }> {
    return this.http.post<{ answer: string }>(this.apiUrl, { query });
  }
}
