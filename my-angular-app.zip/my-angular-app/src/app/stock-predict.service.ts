import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class StockPredictService {
  private apiUrl = 'http://localhost:5045/api/StockPredict/predict/';

  constructor(private http: HttpClient) {}

  getPredictedPrice(symbol: string): Observable<any> {
    return this.http.get(`${this.apiUrl}${symbol}`);
  }
}
