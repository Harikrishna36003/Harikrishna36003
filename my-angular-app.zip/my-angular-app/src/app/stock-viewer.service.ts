// src/app/services/stock.service.ts
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
 
export interface CompanyOverview {
  symbol: string;
  name: string;
  peRatio: number;
  pegRatio: number;
  eps: number;
  profitMargin: number; // e.g., 0.28 for 28%
  dividendYield: number; // e.g., 0.02 for 2%
  beta: number;
  returnOnEquityTTM: number; // e.g., 0.15 for 15%
  returnOnAssetsTTM: number; // e.g., 0.05 for 5%
}
 
@Injectable({
  providedIn: 'root'
})
export class StockService {
  private baseUrl = 'http://localhost:5258/api/CompanyOverview'; // Ensure your backend is running
 
  constructor(private http: HttpClient) {}
 
  getStockOverview(symbol: string): Observable<CompanyOverview> {
    return this.http.get<CompanyOverview>(`${this.baseUrl}/${symbol.toUpperCase()}`);
  }
}