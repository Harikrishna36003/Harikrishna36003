import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Chart, registerables, ChartOptions, ChartData } from 'chart.js';
import {CompanyOverview } from '../stock-viewer.service';
import { StockService } from '../stock-viewer.service';
import { HeaderComponent } from "../header/header.component";
Chart.register(...registerables);
 
export interface MetricCardData {
  label: string;
  value: string | number;
  explanation: string;
  valueColor?: string; // For specific v
  isPercentage?: boolean; // If the raw value is a percentage that chart needs scaled
  rawValueForChart?: number; // Raw value to be used in chart if different from display
}
 
@Component({
  selector: 'app-stock-viewer',
  standalone: true,
  imports: [CommonModule, FormsModule, HeaderComponent],
  templateUrl: './stock-viewer.component.html',
  styleUrls: ['./stock-viewer.component.css']
})
export class StockViewerComponent implements OnInit {
  company?: CompanyOverview;
  symbol: string = ''; // e.g., AAPL, MSFT. User will input this.
  chart?: Chart;
  metricCards: MetricCardData[] = [];
  popularStocks: string[] = ['AAPL', 'MSFT', 'GOOGL', 'AMZN'];
  isLoading: boolean = false;
  errorMessage: string = '';
 
  constructor(private stockService: StockService) {}
 
  ngOnInit() {
    // Optionally fetch a default stock, e.g., 'AAPL'
    // if (this.popularStocks.length > 0) {
    //   this.fetchStockBySymbol(this.popularStocks[0]);
    // }
  }
 
  fetchStockBySymbol(stockSymbol: string) {
    this.symbol = stockSymbol;
    this.fetchStock();
  }
 
  fetchStock() {
    if (!this.symbol.trim()) {
      this.errorMessage = 'Please enter a stock symbol.';
      return;
    }
    this.isLoading = true;
    this.errorMessage = '';
    this.company = undefined; // Clear previous data
    this.metricCards = [];
    if (this.chart) {
        this.chart.destroy();
        this.chart = undefined;
    }
 
    this.stockService.getStockOverview(this.symbol.trim()).subscribe(
      (data: CompanyOverview) => {
        this.company = data;
        this.populateMetricCards();
        setTimeout(() => this.drawChart(), 0); // Delay chart drawing
        this.isLoading = false;
      },
      (error) => {
        console.error('Error fetching stock data:', error);
        this.errorMessage = `Stock symbol '${this.symbol.toUpperCase()}' not found or backend error. Please try another.`;
        this.company = undefined;
        this.metricCards = [];
        this.isLoading = false;
      }
    );
  }
 
  private formatPercentage(value: number | undefined | null): string {
    if (value === undefined || value === null || isNaN(value)) return 'N/A';
    return (value * 100).toFixed(2) + '%';
  }
 
  private formatCurrency(value: number | undefined | null, currency: string = '$'): string {
    if (value === undefined || value === null || isNaN(value)) return 'N/A';
    return currency + value.toFixed(2);
  }
 
  private formatNumber(value: number | undefined | null): string {
    if (value === undefined || value === null || isNaN(value)) return 'N/A';
    return value.toFixed(2);
  }
 
  populateMetricCards() {
    if (!this.company) return;
 
    this.metricCards = [
      {
        label: 'PE Ratio',
        value: this.formatNumber(this.company.peRatio),
        explanation: this.getPERatioExplanation(this.company.peRatio),
        rawValueForChart: this.company.peRatio
      },
      {
        label: 'PEG Ratio',
        value: this.formatNumber(this.company.pegRatio),
        explanation: this.getPEGRatioExplanation(this.company.pegRatio),
        rawValueForChart: this.company.pegRatio
      },
      {
        label: 'EPS',
        value: this.formatCurrency(this.company.eps),
        explanation: `EPS of ${this.formatCurrency(this.company.eps)} indicates the company's profitability per share. Higher EPS is generally better.`,
        rawValueForChart: this.company.eps
      },
      {
        label: 'Profit Margin',
        value: this.formatPercentage(this.company.profitMargin),
        explanation: `Profit Margin of ${this.formatPercentage(this.company.profitMargin)} shows the percentage of revenue converted to profit. A higher margin is preferred.`,
        valueColor: 'green',
        isPercentage: true,
        rawValueForChart: this.company.profitMargin ? this.company.profitMargin * 100 : undefined
      },
      {
        label: 'Dividend Yield',
        value: this.formatPercentage(this.company.dividendYield),
        explanation: this.getDividendYieldExplanation(this.company.dividendYield),
        isPercentage: true,
        rawValueForChart: this.company.dividendYield ? this.company.dividendYield * 100 : undefined
      },
      {
        label: 'Beta',
        value: this.formatNumber(this.company.beta),
        explanation: this.getBetaExplanation(this.company.beta),
        rawValueForChart: this.company.beta
      },
      {
        label: 'ROE',
        value: this.formatPercentage(this.company.returnOnEquityTTM),
        explanation: `Return on Equity (ROE) of ${this.formatPercentage(this.company.returnOnEquityTTM)} reflects management's efficiency at generating profits from shareholder equity. Higher is generally better.`,
        isPercentage: true,
        rawValueForChart: this.company.returnOnEquityTTM ? this.company.returnOnEquityTTM * 100 : undefined
      },
      {
        label: 'ROA',
        value: this.formatPercentage(this.company.returnOnAssetsTTM),
        explanation: `Return on Assets (ROA) of ${this.formatPercentage(this.company.returnOnAssetsTTM)} shows how efficiently assets generate earnings. Higher is generally better.`,
        isPercentage: true,
        rawValueForChart: this.company.returnOnAssetsTTM ? this.company.returnOnAssetsTTM * 100 : undefined
      }
    ];
  }
 
  // Individual explanation methods
  getPERatioExplanation(peRatio?: number): string {
    if (peRatio === undefined || peRatio === null || isNaN(peRatio)) return 'PE Ratio data not available. This ratio helps determine if a stock is over or undervalued by comparing its price to its earnings per share.';
    if (peRatio < 0) return `The PE Ratio (${this.formatNumber(peRatio)}) is negative, indicating the company has negative earnings.`;
    if (peRatio < 15) return `The PE Ratio (${this.formatNumber(peRatio)}) is low, possibly indicating undervaluation or lower growth expectations.`;
    if (peRatio <= 25) return `The PE Ratio (${this.formatNumber(peRatio)}) is moderate, suggesting fair valuation for stable companies.`;
    return `The PE Ratio (${this.formatNumber(peRatio)}) is high, indicating possible overvaluation or high growth expectations.`;
  }
 
  getPEGRatioExplanation(pegRatio?: number): string {
    if (pegRatio === undefined || pegRatio === null || isNaN(pegRatio)) return 'PEG Ratio data not available. This ratio compares PE to earnings growth rate, offering a more complete picture of valuation.';
    if (pegRatio < 1) return `PEG Ratio (${this.formatNumber(pegRatio)}) below 1 may indicate undervaluation relative to expected growth.`;
    if (pegRatio <= 2) return `PEG Ratio (${this.formatNumber(pegRatio)}) suggests fair valuation considering its growth prospects.`;
    return `PEG Ratio (${this.formatNumber(pegRatio)}) above 2 could indicate overvaluation, even if growth is high.`;
  }
 
  getDividendYieldExplanation(dividendYield?: number): string {
    if (dividendYield === undefined || dividendYield === null || isNaN(dividendYield)) return 'Dividend Yield data not available. This shows the annual dividend payout as a percentage of the stock price.';
    const yieldPercent = this.formatPercentage(dividendYield);
    if (dividendYield > 0) return `Dividend Yield of ${yieldPercent} provides income to investors. Higher yields can be attractive but also check dividend sustainability.`;
    return `No dividend yield (0%), meaning the company does not currently pay dividends or data is unavailable.`;
  }
 
  getBetaExplanation(beta?: number): string {
    if (beta === undefined || beta === null || isNaN(beta)) return 'Beta data not available. Beta measures a stock\'s volatility relative to the overall market (e.g., S&P 500).';
    if (beta < 1) return `Beta (${this.formatNumber(beta)}) suggests the stock is less volatile than the market.`;
    if (beta === 1) return `Beta (${this.formatNumber(beta)}) indicates volatility similar to the market.`;
    return `Beta (${this.formatNumber(beta)}) suggests the stock is more volatile than the market.`;
  }
 
  // src/app/components/stock-viewer/stock-viewer.component.ts
 
// ... (imports and other class code remains the same)
 
drawChart() {
  const canvas = document.getElementById('metricsChart') as HTMLCanvasElement;
  if (!canvas || !this.company || this.metricCards.length === 0) return;
 
  const ctx = canvas.getContext('2d');
  if (!ctx) return;
 
  if (this.chart) {
    this.chart.destroy();
    this.chart = undefined; // Ensure chart is cleared for recreation
  }
 
  const chartDataValues = this.metricCards.map(card => card.rawValueForChart ?? 0);
  const chartLabels = this.metricCards.map(card => card.label);
 
  const observedColors = [
      'rgba(54, 162, 235, 0.9)',   // PE Ratio (Strong Blue)
      'rgba(100, 181, 246, 0.9)',  // PEG Ratio (Lighter Blue)
      'rgba(75, 192, 192, 0.9)',   // EPS (Teal/Cyan)
      'rgba(165, 214, 167, 0.9)',  // Profit Margin (Light Green)
      'rgba(255, 206, 86, 0.9)',   // Dividend Yield (Yellow)
      'rgba(193, 156, 220, 0.9)',  // Beta (Light Purple)
      'rgba(124, 179, 66, 0.9)',   // ROE (Mid Green)
      'rgba(255, 159, 64, 0.9)'    // ROA (Orange)
  ];
 
  const data: ChartData = {
      labels: chartLabels,
      datasets: [{
        data: chartDataValues,
        backgroundColor: observedColors,
        borderWidth: 0,
        barPercentage: 0.6,
        categoryPercentage: 0.7
      }]
  };
 
  const options: ChartOptions = {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
          legend: { display: false },
          tooltip: {
              enabled: true,
              callbacks: {
                  label: function(context) {
                      let label = context.dataset.label || '';
                      if (label) {
                          label += ': ';
                      }
                      if (context.parsed.y !== null) {
                          // Access originalMetrics safely
                          const originalMetricsArray = (this as any)?.$context?.chart?.config?.data?.originalMetrics;
                          if (Array.isArray(originalMetricsArray) && originalMetricsArray[context.dataIndex]) {
                              const originalMetric = originalMetricsArray[context.dataIndex];
                              if (originalMetric.isPercentage) {
                                  label += (context.parsed.y).toFixed(2) + '%';
                              } else if (originalMetric.label === 'EPS') {
                                  label += '$' + (context.parsed.y).toFixed(2);
                              } else {
                                  label += (context.parsed.y).toFixed(2);
                              }
                          } else {
                              label += (context.parsed.y).toFixed(2); // Fallback if originalMetric is not found
                          }
                      }
                      return label;
                  }
              }
          }
      },
      scales: {
        y: {
          beginAtZero: true,
          grid: {
            // drawBorder: false, // THIS WAS THE ERROR: REMOVE 'drawBorder' from here
            color: '#e9ecef'      // This styles the horizontal grid lines
          },
          border: {               // ADD/USE THIS to control the Y-axis line itself
            display: false        // Set to false to hide the Y-axis line (consistent with screenshot)
          },
          ticks: { color: '#6c757d', padding: 10 }
        },
        x: {
          grid: { display: false }, // This correctly hides vertical grid lines
          ticks: { color: '#495057' }
        }
      }
  };
  // Add original metrics to config for tooltip access
  (data as any).originalMetrics = this.metricCards;
 
 
  this.chart = new Chart(ctx, { type: 'bar', data, options });
}
 
// ... (rest of the component code)
}